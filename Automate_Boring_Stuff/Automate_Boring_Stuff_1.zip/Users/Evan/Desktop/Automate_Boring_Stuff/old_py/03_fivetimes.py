#prints jimmy five times. I'm going to skip over these exercises until
#i reach something interesting
#epiercy 5/13/18

print('My name is')
for i in range(5):
    print('Jimmy Five Times (', i, ')')
